module com.example.sestnactymaturita {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.sestnactymaturita to javafx.fxml;
    exports com.example.sestnactymaturita;

}