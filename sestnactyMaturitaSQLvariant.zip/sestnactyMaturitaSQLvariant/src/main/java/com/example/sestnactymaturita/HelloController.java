package com.example.sestnactymaturita;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HelloController {

    private ObservableList<String> users = FXCollections.observableArrayList();

    // Instance of dbconnect to handle database connection
    private dbconnect dbConnection;

    @FXML
    private TextField nameTextField;

    @FXML
    private ListView<String> userList;

    @FXML
    private TextField prijmeniUzivatele;

    @FXML
    private TextField emailUzivatele;

    @FXML
    private TextField nickUzivatele;

    @FXML
    void initialize() throws SQLException {
        dbConnection = new dbconnect("it-jmenoprijmeni", "heslo", "sql.stredniskola.com", "jmenoprijmeni");
        dbConnection.connect();
        loadUsersFromDatabase();
    }



    @FXML
    void addUser(ActionEvent event) {
        String name = nameTextField.getText();
        String surname = prijmeniUzivatele.getText();
        String email = emailUzivatele.getText();
        String username = nickUzivatele.getText();

        if (!name.isEmpty() && !surname.isEmpty() && !username.isEmpty()) {
            String fullName = name + " " + surname;
            if (!email.isEmpty()) {
                fullName += ", " + email;
            }

            addUserToDatabase(username, fullName);
            users.add(fullName);
            showAlert("Úspěch", "Uživatel byl úspěšně přidán.");

            nameTextField.clear();
            prijmeniUzivatele.clear();
            emailUzivatele.clear();
            nickUzivatele.clear();
        } else {
            showAlert("Chyba", "Vyplňte povinné údaje: jméno, příjmení a uživatelské jméno.");
        }
    }

    @FXML
    void delUser(ActionEvent event) {
        String selectedUser = userList.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            deleteUserFromDatabase(selectedUser);
            users.remove(selectedUser);
            showAlert("Úspěch", "Uživatel byl úspěšně odstraněn.");
        } else {
            showAlert("Chyba", "Nebyl vybrán žádný uživatel k odstranění.");
        }
    }

    @FXML
    void findUser(ActionEvent event) {
        String searchString = nickUzivatele.getText();
        if (!searchString.isEmpty()) {
            try {
                String sql = "SELECT * FROM users WHERE username LIKE ?";
                PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
                statement.setString(1, '%' + searchString + '%');
                ResultSet resultSet = statement.executeQuery();
                users.clear();
                while (resultSet.next()) {
                    String fullName = resultSet.getString("full_name");
                    users.add(fullName);
                }
                userList.setItems(users);
            } catch (SQLException e) {
                showAlert("Chyba", "Chyba při vyhledávání uživatelů: " + e.getMessage());
            }
        } else {
            showAlert("Chyba", "Zadejte uživatelské jméno pro vyhledávání.");
        }
    }

    private void deleteUserFromDatabase(String user) {
        try {
            String sql = "DELETE FROM users WHERE username = ?";
            PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
            statement.setString(1, user);
            statement.executeUpdate();
        } catch (SQLException e) {
            showAlert("Chyba", "Chyba při mazání uživatele z databáze: " + e.getMessage());
        }
    }

    private void loadUsersFromDatabase() {
        try {
            String sql = "SELECT * FROM users";
            Statement statement = dbConnection.getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            users.clear();
            while (resultSet.next()) {
                String fullName = resultSet.getString("full_name");
                users.add(fullName);
            }
            userList.setItems(users);
        } catch (SQLException e) {
            showAlert("Chyba", "Chyba při načítání uživatelů z databáze: " + e.getMessage());
        }
    }

    private void addUserToDatabase(String username, String fullName) {
        try {
            String sql = "INSERT INTO users (username, full_name) VALUES (?, ?)";
            PreparedStatement statement = dbConnection.getConnection().prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, fullName);
            statement.executeUpdate();
        } catch (SQLException e) {
            showAlert("Chyba", "Chyba při přidávání uživatele do databáze: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
