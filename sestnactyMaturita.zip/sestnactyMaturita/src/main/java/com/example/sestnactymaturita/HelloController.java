package com.example.sestnactymaturita;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HelloController {

    private ObservableList<String> users = FXCollections.observableArrayList();
    private static final String STORAGE_FILE = "diary_storage.txt";

    @FXML
    private TextField nameTextField;

    @FXML
    private ListView<String> userList;

    @FXML
    private TextField prijmeniUzivatele;

    @FXML
    private TextField emailUzivatele;

    @FXML
    private TextField nickUzivatele;

    @FXML
    void initialize() {
        createStorageFileIfNotExists();
        loadUsersFromStorage();
    }

    private void createStorageFileIfNotExists() {
        File file = new File(STORAGE_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                showAlert("Chyba", "Nelze vytvořit soubor: " + e.getMessage());
            }
        }
    }

    private void loadUsersFromStorage() {
        users.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(STORAGE_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                users.add(line);
            }
        } catch (IOException e) {
            showAlert("Chyba", "Chyba při čtení ze souboru: " + e.getMessage());
        }
        userList.setItems(users);
    }

    @FXML
    void addUser(ActionEvent event) {
        String name = nameTextField.getText();
        String surname = prijmeniUzivatele.getText();
        String email = emailUzivatele.getText();
        if (!name.isEmpty() && !surname.isEmpty()) {
            String fullName = name + " " + surname;
            if (!email.isEmpty()) {
                fullName += ", " + email;
            }
            users.add(fullName);
            saveUsersToStorage();
            showAlert("Úspěch", "Uživatel byl úspěšně přidán.");
            nameTextField.clear();
            prijmeniUzivatele.clear();
            emailUzivatele.clear();
        } else {
            showAlert("Chyba", "Vyplňte povinně jméno a příjmení uživatele.");
        }
    }

    @FXML
    void delUser(ActionEvent event) {
        String selectedUser = userList.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            users.remove(selectedUser);
            saveUsersToStorage();
            showAlert("Úspěch", "Uživatel byl úspěšně odstraněn.");
        } else {
            showAlert("Chyba", "Nebyl vybrán žádný uživatel k odstranění.");
        }
    }

    @FXML
    void findUser(ActionEvent event) {
        String searchString = nickUzivatele.getText();
        if (!searchString.isEmpty()) {
            boolean found = false;
            for (int i = 0; i < users.size(); i++) {
                String user = users.get(i);
                if (user.startsWith(searchString)) {
                    userList.scrollTo(i);
                    userList.getSelectionModel().clearAndSelect(i);
                    found = true;
                    break;
                }
            }
            if (!found) {
                showAlert("Chyba", "Uživatel s daným jménem nebyl nalezen.");
            }
        } else {
            showAlert("Chyba", "Zadejte jméno uživatele pro vyhledání.");
        }
    }

    private void saveUsersToStorage() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STORAGE_FILE))) {
            for (String user : users) {
                writer.write(user);
                writer.newLine();
            }
        } catch (IOException e) {
            showAlert("Chyba", "Chyba při zápisu do souboru: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
