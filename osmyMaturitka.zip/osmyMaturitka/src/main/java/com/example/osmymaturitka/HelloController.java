package com.example.osmymaturitka;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.text.DecimalFormat;

public class HelloController {
    @FXML
    private Button objem;

    @FXML
    private TextField polomerPodstavy;

    @FXML
    private Button povrch;

    @FXML
    private TextField vyskaValce;

    @FXML
    private Label vysledek;

    @FXML
    void calculateVolume() {
        try {
            double radius = Double.parseDouble(polomerPodstavy.getText());
            double height = Double.parseDouble(vyskaValce.getText());

            double volume = Math.PI * Math.pow(radius, 2) * height;
            String formattedVolume = new DecimalFormat("#.##").format(volume);
            vysledek.setText("Objem válce: " + formattedVolume + " cm³");
        } catch (NumberFormatException e) {
            vysledek.setText("Chyba: Zadejte platná čísla.");
        }
    }

    @FXML
    void calculateSurfaceArea() {
        try {
            double radius = Double.parseDouble(polomerPodstavy.getText());
            double height = Double.parseDouble(vyskaValce.getText());

            double surfaceArea = 2 * Math.PI * radius * (radius + height);
            String formattedSurfaceArea = new DecimalFormat("#.##").format(surfaceArea);
            vysledek.setText("Povrch válce: " + formattedSurfaceArea + " cm²");
        } catch (NumberFormatException e) {
            vysledek.setText("Chyba: Zadejte platná čísla.");
        }
    }
}
