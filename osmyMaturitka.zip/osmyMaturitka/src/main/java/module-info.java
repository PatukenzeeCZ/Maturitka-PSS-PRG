module com.example.osmymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.osmymaturitka to javafx.fxml;
    exports com.example.osmymaturitka;
}