module com.example.sedmymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.sedmymaturitka to javafx.fxml;
    exports com.example.sedmymaturitka;
}