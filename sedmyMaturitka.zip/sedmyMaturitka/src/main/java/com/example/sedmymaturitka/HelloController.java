package com.example.sedmymaturitka;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.util.HashMap;
import java.util.Map;

public class HelloController {

    @FXML
    private Button preloz;

    @FXML
    private TextField vpisovani;

    @FXML
    private TextArea vypis;

    private final Map<Character, String> morseAbeceda = new HashMap<>();

    public void initialize() {
        // Inicializace Morseovy abecedy
        inicializovatMorseAbecedu();

        // Přiřazení akce tlačítku preloz
        preloz.setOnAction(event -> prelozMorseovku());
    }

    @FXML
    private void prelozMorseovku() {
        String text = vpisovani.getText().toUpperCase();
        StringBuilder prelozenyText = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char znak = text.charAt(i);
            if (morseAbeceda.containsKey(znak)) {
                prelozenyText.append(morseAbeceda.get(znak)).append(" ");
            } else if (znak == ' ') {
                prelozenyText.append("/ ");
            }
        }

        vypis.setText(prelozenyText.toString());
    }

    private void inicializovatMorseAbecedu() {
        morseAbeceda.put('A', ".-");
        morseAbeceda.put('B', "-...");
        morseAbeceda.put('C', "-.-.");
        morseAbeceda.put('D', "-..");
        morseAbeceda.put('E', ".");
        morseAbeceda.put('F', "..-.");
        morseAbeceda.put('G', "--.");
        morseAbeceda.put('H', "....");
        morseAbeceda.put('I', "..");
        morseAbeceda.put('J', ".---");
        morseAbeceda.put('K', "-.-");
        morseAbeceda.put('L', ".-..");
        morseAbeceda.put('M', "--");
        morseAbeceda.put('N', "-.");
        morseAbeceda.put('O', "---");
        morseAbeceda.put('P', ".--.");
        morseAbeceda.put('Q', "--.-");
        morseAbeceda.put('R', ".-.");
        morseAbeceda.put('S', "...");
        morseAbeceda.put('T', "-");
        morseAbeceda.put('U', "..-");
        morseAbeceda.put('V', "...-");
        morseAbeceda.put('W', ".--");
        morseAbeceda.put('X', "-..-");
        morseAbeceda.put('Y', "-.--");
        morseAbeceda.put('Z', "--..");
        morseAbeceda.put('0', "-----");
        morseAbeceda.put('1', ".----");
        morseAbeceda.put('2', "..---");
        morseAbeceda.put('3', "...--");
        morseAbeceda.put('4', "....-");
        morseAbeceda.put('5', ".....");
        morseAbeceda.put('6', "-....");
        morseAbeceda.put('7', "--...");
        morseAbeceda.put('8', "---..");
        morseAbeceda.put('9', "----.");
        morseAbeceda.put('.', ".-.-.-");
        morseAbeceda.put(',', "--..--");
        morseAbeceda.put('?', "..--..");
        morseAbeceda.put('!', "-.-.--");
        morseAbeceda.put('/', "-..-.");
        morseAbeceda.put('(', "-.--.");
        morseAbeceda.put(')', "-.--.-");
        morseAbeceda.put('&', ".-...");
        morseAbeceda.put(':', "---...");
        morseAbeceda.put(';', "-.-.-.");
        morseAbeceda.put('=', "-...-");
        morseAbeceda.put('+', ".-.-.");
        morseAbeceda.put('-', "-....-");
        morseAbeceda.put('_', "..--.-");
        morseAbeceda.put('"', ".-..-.");
        morseAbeceda.put('$', "...-..-");
        morseAbeceda.put('@', ".--.-.");
        morseAbeceda.put(' ', "/");
    }
}
