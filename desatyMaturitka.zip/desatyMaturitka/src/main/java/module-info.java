module com.example.desatymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.desatymaturitka to javafx.fxml;
    exports com.example.desatymaturitka;
}