package com.example.desatymaturitka;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private TextField hmotnost;

    @FXML
    private Button vypocitejBMI;

    @FXML
    private TextField vyska;

    @FXML
    private Label vysledek;

    @FXML
    void initialize() {
        vypocitejBMI.setOnAction(event -> {
            // Při stisknutí tlačítka pro výpočet BMI
            try {
                double hmotnostValue = Double.parseDouble(hmotnost.getText());
                double vyskaValue = Double.parseDouble(vyska.getText()) / 100; // Převést výšku na metry
                double bmi = hmotnostValue / (vyskaValue * vyskaValue); // Výpočet BMI
                vysledek.setText(String.format(" %.2f", bmi)); // Zobrazit výsledek s dvěma desetinnými místy
            } catch (NumberFormatException e) {
                vysledek.setText("Chyba: Zkontrolujte, zda jste správně zadal/a hmotnost a výšku.");
            } catch (ArithmeticException e) {
                vysledek.setText("Chyba: Dělení nulou není povoleno. Zkontrolujte, zda jste správně zadal/a výšku.");
            }
        });
    } }