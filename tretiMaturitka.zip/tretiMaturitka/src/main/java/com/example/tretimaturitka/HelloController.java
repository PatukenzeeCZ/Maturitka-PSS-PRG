package com.example.tretimaturitka;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label cislo;

    @FXML
    protected void onHelloButtonClick() {
        cislo.setText("Welcome to JavaFX Application!");
    }
}