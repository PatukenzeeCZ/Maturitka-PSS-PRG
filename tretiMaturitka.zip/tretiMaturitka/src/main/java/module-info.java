module com.example.tretimaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.tretimaturitka to javafx.fxml;
    exports com.example.tretimaturitka;
}