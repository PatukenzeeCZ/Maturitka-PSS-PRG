package com.example.trinactymaturita;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;

public class HelloController {

    @FXML
    private TextField napsaneCislo;

    @FXML
    private Button prelozTlacitko;

    @FXML
    private Button ulozeniTlactiko;

    @FXML
    private ChoiceBox<String> vyberSoustavy;

    @FXML
    private TextArea vypisCisel;

    @FXML
    private void initialize() {
        // Přidání možností do ChoiceBoxu
        vyberSoustavy.getItems().addAll("DEC -> BIN", "DEC -> OCT", "DEC -> HEX");

        // Nastavení akce pro tlačítko prelozTlacitko
        prelozTlacitko.setOnAction(event -> prelozCislo());

        // Nastavení ikony pro tlačítko ulozeniTlactiko
        Image image = new Image(getClass().getResourceAsStream("/save.png"));
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(16); // Změna šířky ikony na 16 px
        imageView.setFitHeight(16); // Změna výšky ikony na 16 px
        ulozeniTlactiko.setGraphic(imageView);

        // Nastavení akce pro tlačítko ulozeniTlactiko
        ulozeniTlactiko.setOnAction(event -> ulozitDoClipboardu());
    }


    // Metoda pro převod čísla podle vybraného způsobu
    private void prelozCislo() {
        String cislo = napsaneCislo.getText();
        String soustava = vyberSoustavy.getValue();
        String prelozeneCislo = "";

        if (soustava != null && !cislo.isEmpty()) {
            switch (soustava) {
                case "DEC -> BIN":
                    prelozeneCislo = Integer.toBinaryString(Integer.parseInt(cislo));
                    break;
                case "DEC -> OCT":
                    prelozeneCislo = Integer.toOctalString(Integer.parseInt(cislo));
                    break;
                case "DEC -> HEX":
                    prelozeneCislo = Integer.toHexString(Integer.parseInt(cislo)).toUpperCase();
                    break;
            }
            vypisCisel.setText(prelozeneCislo);
        } else {
            vypisCisel.setText("Vyberte soustavu a zadejte číslo.");
        }
    }

    // Metoda pro uložení převedeného čísla do clipboardu
    private void ulozitDoClipboardu() {
        String prelozeneCislo = vypisCisel.getText();
        Clipboard clipboard = Clipboard.getSystemClipboard();
        ClipboardContent content = new ClipboardContent();
        content.putString(prelozeneCislo);
        clipboard.setContent(content);
    }
}
