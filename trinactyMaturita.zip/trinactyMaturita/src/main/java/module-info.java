module com.example.trinactymaturita {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.trinactymaturita to javafx.fxml;
    exports com.example.trinactymaturita;
}