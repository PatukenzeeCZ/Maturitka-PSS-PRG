module com.example.prvnimaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.prvnimaturitka to javafx.fxml;
    exports com.example.prvnimaturitka;
}