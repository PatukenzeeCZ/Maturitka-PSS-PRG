package com.example.patnactymaturita;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    @FXML
    private TextField hrubaMzda;



    @FXML
    private TextField osobniOhodnoceni;

    @FXML
    private Label pocetDeti;



    @FXML
    private Label socialniPojisteni;



    @FXML
    private Label vysledekLabel;

    @FXML
    private Label zalohaNaDan;

    @FXML
    private Label zdravotniPojisteni;

    private int pocetDetiValue = 0;

    // Metoda pro výpočet čisté mzdy
    @FXML
    private void vypocitejCistouMzdu() {
        try {
            double hrubaMzdaValue = 0;
            if (hrubaMzda.getText().equals("")) {
                errorAlert("Zadejte výši hrubé mzdy", null);
                return; // Ukončit metodu v případě neplatného vstupu
            } else {
                hrubaMzdaValue = Double.parseDouble(hrubaMzda.getText().replace(" ", ""));
            }

            double osobniOhodnoceniValue = 0;
            if (!osobniOhodnoceni.getText().equals("")) {
                osobniOhodnoceniValue = Double.parseDouble(osobniOhodnoceni.getText().replace(" ", ""));
            } else {
                osobniOhodnoceni.setText("0");
            }

            double hrubaMzdaSum = hrubaMzdaValue + osobniOhodnoceniValue;
            double zdravotni = 0.045 * hrubaMzdaSum;
            double socialni = 0.065 * hrubaMzdaSum;
            double zaloha = (Math.ceil(hrubaMzdaSum / 100.0) * 100) * 0.15;

            if (pocetDetiValue > 0) {
                switch (pocetDetiValue) {
                    case 1:
                        zaloha -= 1267;
                        break;
                    case 2:
                        zaloha -= (1267 + 1617);
                        break;
                    case 3:
                        zaloha -= (1267 + 1617 + 2017);
                        break;
                    default:
                        int childminus3 = pocetDetiValue - 3;
                        zaloha -= (1267 + 1617 + 2017) + (2017 * childminus3);
                        break;
                }
            } else {
                zaloha -= 2320;
            }

            double cistaMzda = hrubaMzdaSum - socialni - zdravotni - zaloha;

            // Nastavení výsledku
            vysledekLabel.setText(String.format("Čistá mzda: %.2f Kč", cistaMzda));
            zdravotniPojisteni.setText(String.format("%.2f Kč", zdravotni));
            socialniPojisteni.setText(String.format("%.2f Kč", socialni));
            zalohaNaDan.setText(String.format("%.2f Kč", zaloha));
        } catch (NumberFormatException e) {
            // Pokud uživatel zadal neplatné hodnoty
            vysledekLabel.setText("Zadejte platná čísla.");
        }
    }

    // Metoda pro přidání dítěte
    @FXML
    private void pridejDite(ActionEvent event) {
        pocetDetiValue++;
        pocetDeti.setText(String.valueOf(pocetDetiValue));
    }

    // Metoda pro odebrání dítěte
    @FXML
    private void odeberDite(ActionEvent event) {
        if (pocetDetiValue > 0) {
            pocetDetiValue--;
            pocetDeti.setText(String.valueOf(pocetDetiValue));
        }
    }

    // Metoda pro zobrazení chybového dialogu
    private void errorAlert(String header, String content) {
        // Implementace chybového dialogu
    }
}
