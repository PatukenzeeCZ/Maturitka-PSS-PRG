module com.example.patnactymaturita {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.patnactymaturita to javafx.fxml;
    exports com.example.patnactymaturita;
}