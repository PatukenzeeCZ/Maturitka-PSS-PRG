package com.example.patymaturitka;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.util.Random;

public class HelloController {

    @FXML
    private ImageView diceImage;

    private final Image[] diceImages = new Image[6];

    public void initialize() {
        loadDiceImages();
        // Při inicializaci zobrazí náhodný obrázek kostky
        displayRandomDice();
    }

    private void displayRandomDice() {
        Random random = new Random();
        int randomNumber = random.nextInt(6); // Generuje náhodné číslo mezi 0 a 5

        diceImage.setImage(diceImages[randomNumber]);
    }

    @FXML
    void hodKostkou() {
        // Při kliknutí na tlačítko zobrazí další náhodný obrázek kostky
        displayRandomDice();
    }

    private void loadDiceImages() {
        for (int i = 0; i < 6; i++) {
            String imagePath = "src/main/resources/Images/dice" + (i + 1) + ".png";
            File imageFile = new File(imagePath);
            diceImages[i] = new Image(imageFile.toURI().toString());
        }
    }
}
