module com.example.patymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.patymaturitka to javafx.fxml;
    exports com.example.patymaturitka;
}