package com.example.ctvrtymaturitka;

import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;

public class HelloController {
    @FXML
    private AnchorPane panel1;

    @FXML
    private AnchorPane panel2;

    @FXML
    void togglePanels() {
        panel1.setVisible(!panel1.isVisible());
        panel2.setVisible(!panel2.isVisible());
    }
}
