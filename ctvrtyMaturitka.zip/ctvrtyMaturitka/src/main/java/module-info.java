module com.example.ctvrtymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ctvrtymaturitka to javafx.fxml;
    exports com.example.ctvrtymaturitka;
}