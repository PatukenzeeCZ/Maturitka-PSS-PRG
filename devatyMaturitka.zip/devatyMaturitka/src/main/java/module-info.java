module com.example.osmymaturitka {
    requires javafx.controls;
    requires javafx.fxml;
    exports com.example.devatymaturitka;
    opens com.example.devatymaturitka to javafx.fxml;
}