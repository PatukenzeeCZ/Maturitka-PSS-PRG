package com.example.devatymaturitka;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.text.DecimalFormat;

public class HelloController {

    @FXML
    private TextField cylinderRadiusField;

    @FXML
    private TextField cylinderHeightField;

    @FXML
    private Label cylinderResultLabel;

    @FXML
    private TextField sphereRadiusField;

    @FXML
    private Label sphereResultLabel;

    @FXML
    private TextField boxEdgeAField;

    @FXML
    private TextField boxEdgeBField;

    @FXML
    private TextField boxEdgeCField;

    @FXML
    private Label boxResultLabel;

    @FXML
    void calculateCylinder() {
        try {
            double radius = Double.parseDouble(cylinderRadiusField.getText());
            double height = Double.parseDouble(cylinderHeightField.getText());

            double volume = Math.PI * Math.pow(radius, 2) * height;
            double surfaceArea = 2 * Math.PI * radius * (radius + height);

            cylinderResultLabel.setText("Objem válce: " + formatDecimal(volume) + " cm³");
        } catch (NumberFormatException e) {
            cylinderResultLabel.setText("Chyba: Zadejte platná čísla.");
        }
    }

    @FXML
    void calculateCylinderSurfaceArea() {
        try {
            double radius = Double.parseDouble(cylinderRadiusField.getText());
            double height = Double.parseDouble(cylinderHeightField.getText());

            double surfaceArea = 2 * Math.PI * radius * (radius + height);

            cylinderResultLabel.setText("Povrch válce: " + formatDecimal(surfaceArea) + " cm²");
        } catch (NumberFormatException e) {
            cylinderResultLabel.setText("Chyba: Zadejte platná čísla.");
        }
    }

    @FXML
    void calculateSphereVolume() {
        try {
            double radius = Double.parseDouble(sphereRadiusField.getText());

            double volume = (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
            double surfaceArea = 4 * Math.PI * Math.pow(radius, 2);

            sphereResultLabel.setText("Objem koule: " + formatDecimal(volume) + " cm³");
        } catch (NumberFormatException e) {
            sphereResultLabel.setText("Chyba: Zadejte platná čísla.");
        }
    }

    @FXML
    void calculateSphereSurfaceArea() {
        try {
            double radius = Double.parseDouble(sphereRadiusField.getText());

            double surfaceArea = 4 * Math.PI * Math.pow(radius, 2);

            sphereResultLabel.setText("Povrch koule: " + formatDecimal(surfaceArea) + " cm²");
        } catch (NumberFormatException e) {
            sphereResultLabel.setText("Chyba: Zadejte platná čísla.");
        }
    }

    @FXML
    void calculateBoxVolume() {
        try {
            double edgeA = Double.parseDouble(boxEdgeAField.getText());
            double edgeB = Double.parseDouble(boxEdgeBField.getText());
            double edgeC = Double.parseDouble(boxEdgeCField.getText());

            double volume = edgeA * edgeB * edgeC;
            boxResultLabel.setText("Objem kvádru: " + formatDecimal(volume) + " cm³");
        } catch (NumberFormatException e) {
            boxResultLabel.setText("Chyba: Zadejte platná čísla.");
        }
    }

    @FXML
    void calculateBoxSurfaceArea() {
        try {
            double edgeA = Double.parseDouble(boxEdgeAField.getText());
            double edgeB = Double.parseDouble(boxEdgeBField.getText());
            double edgeC = Double.parseDouble(boxEdgeCField.getText());

            double surfaceArea = 2 * (edgeA * edgeB + edgeA * edgeC + edgeB * edgeC);

            boxResultLabel.setText("Povrch kvádru: " + formatDecimal(surfaceArea) + " cm²");
        } catch (NumberFormatException e) {
            boxResultLabel.setText("Chyba: Zadejte platná čísla.");
        }
    }

    private String formatDecimal(double value) {
        return new DecimalFormat("#.##").format(value);
    }
}
