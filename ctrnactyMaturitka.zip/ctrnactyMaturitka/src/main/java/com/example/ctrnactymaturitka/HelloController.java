package com.example.ctrnactymaturitka;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Text;

public class HelloController {
    @FXML
    private Text predchoziCislo;
    @FXML
    private Label display;

    private double firstNumber = 0;
    private String operator = "";
    private boolean start = true;

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if (start) {
            display.setText("");
            start = false;
        }

        String value = ((Button) event.getSource()).getText();
        display.setText(display.getText() + value);

        // Aktualizace predchoziCislo po zadání čísla
        String previous = predchoziCislo.getText();
        if (!previous.isEmpty() && (previous.charAt(previous.length() - 1) == '+' ||
                previous.charAt(previous.length() - 1) == '-' ||
                previous.charAt(previous.length() - 1) == 'x' ||
                previous.charAt(previous.length() - 1) == '/')) {
            predchoziCislo.setText(previous + " " + value);
        }
    }


    @FXML
    private void handleOperator(ActionEvent event) {
        String value = ((Button) event.getSource()).getText();

        if (!value.equals("=")) {
            if (!operator.isEmpty())
                return;

            operator = value;
            String previous = predchoziCislo.getText();
            String current = display.getText();
            predchoziCislo.setText(previous + " " + current + " " + operator);
            firstNumber = Double.parseDouble(display.getText());
            display.setText("");
        } else {
            if (operator.isEmpty())
                return;

            double secondNumber = Double.parseDouble(display.getText());
            double result = calculate(firstNumber, secondNumber, operator);
            display.setText(String.valueOf(result));
            operator = "";
            start = true;
        }
    }


    @FXML
    private void handleClear(ActionEvent event) {
        predchoziCislo.setText("");
        display.setText("");
    }

    @FXML
    private void handleBackspace(ActionEvent event) {
        String text = display.getText();
        if (!text.isEmpty()) {
            display.setText(text.substring(0, text.length() - 1));
        }
    }

    private double calculate(double firstNumber, double secondNumber, String operator) {
        switch (operator) {
            case "+":
                return firstNumber + secondNumber;
            case "-":
                return firstNumber - secondNumber;
            case "x":
                return firstNumber * secondNumber;
            case "/":
                if (secondNumber == 0)
                    return 0; // Nedefinovaný výsledek pro dělení nulou
                return firstNumber / secondNumber;
            default:
                return 0; // Nepodporovaný operátor
        }
    }
}
