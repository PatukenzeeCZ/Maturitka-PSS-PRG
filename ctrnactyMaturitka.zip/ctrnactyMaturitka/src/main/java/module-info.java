module com.example.ctrnactymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ctrnactymaturitka to javafx.fxml;
    exports com.example.ctrnactymaturitka;
}