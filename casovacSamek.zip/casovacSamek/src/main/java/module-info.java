module com.example.casovacsamek {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;
    requires jdk.internal.le;


    opens com.example.casovacsamek to javafx.fxml;
    exports com.example.casovacsamek;
}