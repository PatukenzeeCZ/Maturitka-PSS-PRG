package com.example.casovacsamek;

import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

import java.net.URISyntaxException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class HelloController implements Initializable, Runnable {

    @FXML
    private ComboBox<Integer> comboHod;

    @FXML
    private ComboBox<Integer> comboMin;

    @FXML
    private ComboBox<Integer> comboSec;

    @FXML
    private AnchorPane panelNastaveni;

    @FXML
    private AnchorPane panelOdpoctu;

    private Thread t;
    private boolean bezi = false;
    private int sekundy;
    private boolean pauza = false;
    Object monitor = new Object();
    MediaPlayer mp;

    @FXML
    private Label popisekHod;

    @FXML
    private Label popisekMin;

    @FXML
    private Label popisekSec;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<Integer> hodinyList = FXCollections.observableArrayList();
        ObservableList<Integer> minutyASekundyList = FXCollections.observableArrayList();

        for (int i = 0; i < 60; i++) {
            hodinyList.add(i);
            minutyASekundyList.add(i);
        }

        comboHod.setItems(hodinyList);
        comboHod.setValue(0);
        comboMin.setItems(minutyASekundyList);
        comboMin.setValue(0);
        comboSec.setItems(minutyASekundyList);
        comboSec.setValue(0);
    }

    @FXML
    void zapnutiCasovace(ActionEvent event) {
        animaceNahoru();
        t = new Thread(this);
        t.setDaemon(true);
        bezi = true;
        nacteniCasu();
        t.start();
    }

    private void nacteniCasu() {
        sekundy = comboHod.getValue() * 3600 + comboMin.getValue() * 60 + comboSec.getValue();
    }

    public void animaceNahoru() {
        TranslateTransition tt1 = new TranslateTransition();
        tt1.setDuration(Duration.millis(800));
        tt1.setToX(0);
        tt1.setToY(-216);
        tt1.setNode(panelNastaveni);
        tt1.play();
    }

    public void animaceDolu() {
        TranslateTransition tt1 = new TranslateTransition();
        tt1.setDuration(Duration.millis(800));
        tt1.setToX(0);
        tt1.setToY(0);
        tt1.setNode(panelNastaveni);
        tt1.play();
    }

    public void zastaveniCasovace(ActionEvent actionEvent) {
        animaceDolu();
        bezi = false;
        synchronized (monitor) {
            monitor.notify();
            pauza = false;
        }
    }

    @Override
    public void run() {
        // Pocitani casu ve vlakne
        long cas = System.currentTimeMillis() + 1000;
        while (bezi) {
            synchronized (monitor) {
                if (pauza) {
                    try {
                        monitor.wait();
                    } catch (InterruptedException e) {
                        System.err.println(e.getMessage());
                    }
                }
                if (System.currentTimeMillis() > cas) {
                    Platform.runLater(this::aktualizujCas);

                    if (sekundy == 0) {
                        try {
                            Media bell = null;
                            URL resource = getClass().getClassLoader().getResource("bell.mp3");
                            if (resource != null) {
                                bell = new Media(resource.toString());
                                mp = new MediaPlayer(bell);
                                mp.play();
                            } else {
                                System.err.println("Soubor 'bell.mp3' nebyl nalezen.");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        bezi = false;
                    } else {
                        sekundy--;
                        cas = System.currentTimeMillis() + 1000;
                    }
                }
            }
        }
    }

    private void aktualizujCas() {
        short hod = (short) (sekundy / 3600);
        popisekHod.setText((hod < 10) ? "0" + hod : "" + hod);
        short min = (short) ((sekundy % 3600) / 60);
        popisekMin.setText((min < 10) ? "0" + min : "" + min);
        short sec = (short) (sekundy % 60);
        popisekSec.setText((sec < 10) ? "0" + sec : "" + sec);
    }

    public void pauzaCasovace(ActionEvent actionEvent) {
        if (!pauza) pauza = true;
        else {
            synchronized (monitor) {
                monitor.notify();
                pauza = false;
            }
        }
    }

    public void resetCasovace(ActionEvent actionEvent) {
        nacteniCasu();
    }
}
