package com.example.druhymaturitka;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {
    @FXML
    private Label cisla;

    private int cislo = 0; // Proměnná pro uchování čísla

    @FXML
    protected void onHelloButtonClick() {
        // Inkrementace čísla o jedna
        cislo++;
        // Nastavení nové hodnoty čísla do labelu
        cisla.setText(Integer.toString(cislo));
    }
}
