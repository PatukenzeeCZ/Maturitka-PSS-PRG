module com.example.druhymaturitka {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.druhymaturitka to javafx.fxml;
    exports com.example.druhymaturitka;
}