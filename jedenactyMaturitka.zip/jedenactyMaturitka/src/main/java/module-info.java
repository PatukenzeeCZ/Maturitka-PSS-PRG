module com.example.jedenactymaturitka {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    opens com.example.jedenactymaturitka to javafx.fxml;
    exports com.example.jedenactymaturitka;
}
