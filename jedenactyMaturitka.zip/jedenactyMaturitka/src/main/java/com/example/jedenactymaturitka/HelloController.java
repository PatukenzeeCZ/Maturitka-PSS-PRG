package com.example.jedenactymaturitka;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebView;

public class HelloController {

    @FXML
    private WebView webView;

    @FXML
    private TextField textField;

    private WebEngine webEngine;

    public void initialize() {
        webEngine = webView.getEngine();
        loadPage("https://www.google.com");
    }

    @FXML
    void loadPage(ActionEvent event) {
        String url = textField.getText();
        if (!url.isEmpty()) {
            webEngine.load(url);
        }
    }

    private void loadPage(String url) {
        webEngine.load(url);
    }

    @FXML
    void goBack(ActionEvent event) {
        WebHistory history = webEngine.getHistory();
        if (history.getCurrentIndex() > 0) {
            history.go(-1);
        }
    }

    @FXML
    void goForward(ActionEvent event) {
        WebHistory history = webEngine.getHistory();
        if (history.getCurrentIndex() < history.getEntries().size() - 1) {
            history.go(1);
        }
    }

    @FXML
    void goHome(ActionEvent event) {
        loadPage("https://www.google.com");
    }
}
